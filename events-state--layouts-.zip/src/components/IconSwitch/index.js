export * from './IconSwitch';
