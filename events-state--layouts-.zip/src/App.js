import { Store } from './components/Store';
import './App.css';

export default function App() {
  return (
    <Store />
  );
}
